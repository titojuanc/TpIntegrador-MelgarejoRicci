package com.mercadotecnico.mr.mercadotecnico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MercadotecnicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
